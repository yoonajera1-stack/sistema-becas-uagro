package com.miapp.software.service;

import com.miapp.software.model.Beca;
import com.miapp.software.repository.BecaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BecaService {

    @Autowired
    private BecaRepository becaRepository;

    // RF-01 - Registrar convocatoria (MO-01)
    public Beca registrar(Beca beca) {
        // RNF-01: Validar campos obligatorios
        if (beca.getNombre() == null || beca.getNombre().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la beca es obligatorio");
        }
        if (beca.getFechaInicio() == null || beca.getFechaFin() == null) {
            throw new IllegalArgumentException("Las fechas de vigencia son obligatorias");
        }
        // Validar que fecha fin no sea menor a fecha inicio
        if (beca.getFechaFin().isBefore(beca.getFechaInicio())) {
            throw new IllegalArgumentException("La fecha de fin no puede ser menor a la fecha de inicio");
        }
        return becaRepository.save(beca);
    }

    // RF-04 - Consultar convocatorias activas (MO-01)
    public List<Beca> listarActivas() {
        return becaRepository.findByEstatusTrue();
    }

    // RF-04 - Consultar todo el historial
    public List<Beca> listarTodas() {
        return becaRepository.findAll();
    }

    // RF-03 - Editar convocatoria (MO-01)
    public Optional<Beca> obtenerPorId(Integer id) {
        return becaRepository.findById(id);
    }

    // RF-03 - Actualizar convocatoria
    public Beca actualizar(Integer id, Beca becaActualizada) {
        return becaRepository.findById(id).map(beca -> {
            beca.setNombre(becaActualizada.getNombre());
            beca.setTipo(becaActualizada.getTipo());
            beca.setMonto(becaActualizada.getMonto());
            // Nota: Verifica si en tu modelo Beca el campo se llama 'descripcionRequisitos' o 'requisitos'
            // beca.setRequisitos(becaActualizada.getRequisitos());
            beca.setFechaInicio(becaActualizada.getFechaInicio());
            beca.setFechaFin(becaActualizada.getFechaFin());
            return becaRepository.save(beca);
        }).orElse(null);
    }

    // RF-05 - Eliminar convocatoria (MO-01)
    public void eliminar(Integer id) {
        becaRepository.deleteById(id);
    }

    // RF-05 - Desactivar convocatoria (Borrado lógico)
    public void desactivar(Integer id) {
        becaRepository.findById(id).ifPresent(beca -> {
            beca.setEstatus(false);
            becaRepository.save(beca);
        });
    }

    // RNF-02 - Validar tiempo de respuesta (3 segundos máx)
    public List<Beca> buscarPorNombre(String nombre) {
        long inicio = System.currentTimeMillis();
        List<Beca> resultados = becaRepository.findByNombreContainingIgnoreCase(nombre);
        long fin = System.currentTimeMillis();
        System.out.println("Tiempo de búsqueda: " + (fin - inicio) + "ms");
        return resultados;
    }
}