package com.miapp.software.service;

import com.miapp.software.model.Estudiante;
import com.miapp.software.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {

    @Autowired
    private EstudianteRepository estudianteRepository;

    // RF-06 - Registrar estudiante (MO-02)
    public Estudiante registrar(Estudiante estudiante) {
        // RNF-05: Validar campos obligatorios
        if (estudiante.getCurp() == null || estudiante.getCurp().isEmpty()) {
            throw new IllegalArgumentException("La CURP es obligatoria");
        }
        if (estudiante.getMatricula() == null || estudiante.getMatricula().isEmpty()) {
            throw new IllegalArgumentException("La matrícula es obligatoria");
        }

        // RF-13: Validar que no haya CURP duplicada
        if (estudianteRepository.findByCurp(estudiante.getCurp()).isPresent()) {
            throw new IllegalArgumentException("La CURP ya está registrada en el sistema");
        }

        // Validar que no haya matrícula duplicada
        if (estudianteRepository.findByMatricula(estudiante.getMatricula()).isPresent()) {
            throw new IllegalArgumentException("La matrícula ya está registrada en el sistema");
        }

        return estudianteRepository.save(estudiante);
    }

    // RF-11 - Listar estudiantes activos (MO-02)
    public List<Estudiante> listarTodos() {
        return estudianteRepository.findByEstatusTrue();
    }

    // ✅ MÉTODO FALTANTE: Buscar estudiante por ID (lo que usa EstudianteController)
    public Optional<Estudiante> buscarPorId(Integer id) {
        return estudianteRepository.findById(id);
    }

    // RF-11 - Buscar por matrícula
    public Optional<Estudiante> buscarPorMatricula(String matricula) {
        return estudianteRepository.findByMatricula(matricula);
    }

    // RF-11 - Buscar por CURP
    public Optional<Estudiante> buscarPorCurp(String curp) {
        return estudianteRepository.findByCurp(curp);
    }

    // RF-10 - Editar estudiante (MO-02)
    public Estudiante actualizar(Integer id, Estudiante estudianteActualizado) {
        return estudianteRepository.findById(id).map(estudiante -> {
            estudiante.setNombre(estudianteActualizado.getNombre());
            estudiante.setCorreo(estudianteActualizado.getCorreo());
            estudiante.setTelefono(estudianteActualizado.getTelefono());
            estudiante.setPromedio(estudianteActualizado.getPromedio());
            estudiante.setSemestre(estudianteActualizado.getSemestre());
            return estudianteRepository.save(estudiante);
        }).orElse(null);
    }

    // RF-12 - Consultar historial de estudiante
    public Optional<Estudiante> obtenerConHistorial(Integer id) {
        return estudianteRepository.findById(id);
    }

    // RNF-06 - Búsqueda por escuela
    public List<Estudiante> buscarPorEscuela(Integer idEscuela) {
        return estudianteRepository.findByEscuela_IdEscuela(idEscuela);
    }
}