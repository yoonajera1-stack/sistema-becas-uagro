package com.miapp.software.service;

import com.miapp.software.model.Personal;
import com.miapp.software.model.Solicitud;
import com.miapp.software.repository.SolicitudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SolicitudService {

    @Autowired
    private SolicitudRepository solicitudRepository;

    // RF-14 - Registrar solicitud (MO-03, C.U.3)
    public Solicitud registrar(Solicitud solicitud) {
        String folio = generarFolio();
        solicitud.setFolio(folio);
        solicitud.setEstado("Pendiente");
        solicitud.setFechaSolicitud(LocalDateTime.now());
        return solicitudRepository.save(solicitud);
    }

    // Generar folio único
    private String generarFolio() {
        String anio = String.valueOf(LocalDateTime.now().getYear());
        String consecutivo = String.format("%06d", solicitudRepository.count() + 1);
        return "BECAS-" + anio + "-" + consecutivo;
    }

    // ✅ MÉTODO FALTANTE: buscarPorId (lo que usa el controller)
    public Optional<Solicitud> buscarPorId(Integer id) {
        return solicitudRepository.findById(id);
    }

    // ✅ MÉTODO FALTANTE: listarTodos (lo que usa el controller)
    public List<Solicitud> listarTodos() {
        return solicitudRepository.findAll();
    }

    // RF-16 - Consultar solicitudes de un estudiante
    public List<Solicitud> listarPorEstudiante(Integer idEstudiante) {
        return solicitudRepository.findByEstudiante_IdEstudiante(idEstudiante);
    }

    // RF-16 - Consultar por estado
    public List<Solicitud> listarPorEstado(String estado) {
        return solicitudRepository.findByEstado(estado);
    }

    // RF-17 - Actualizar estado de solicitud
    public Solicitud actualizarEstado(Integer id, String nuevoEstado, String observaciones) {
        return solicitudRepository.findById(id).map(solicitud -> {
            solicitud.setEstado(nuevoEstado);
            solicitud.setObservaciones(observaciones);
            solicitud.setFechaActualizacion(LocalDateTime.now());
            return solicitudRepository.save(solicitud);
        }).orElse(null);
    }

    // C.U.4 - Validar documentación
    public Solicitud validarDocumentacion(Integer idSolicitud, Personal personalValidador) {
        return solicitudRepository.findById(idSolicitud).map(solicitud -> {
            solicitud.setPersonalValidacion(personalValidador);
            solicitud.setEstado("Documentación Completa");
            solicitud.setFechaActualizacion(LocalDateTime.now());
            return solicitudRepository.save(solicitud);
        }).orElse(null);
    }

    // C.U.4 - Enviar a instancia externa
    public Solicitud enviarAInstancia(Integer id) {
        return solicitudRepository.findById(id).map(solicitud -> {
            solicitud.setEstado("Enviada a Instancia");
            solicitud.setFechaActualizacion(LocalDateTime.now());
            return solicitudRepository.save(solicitud);
        }).orElse(null);
    }

    // C.U.4 - Registrar respuesta de instancia
    public Solicitud registrarRespuestaInstancia(Integer id, String respuesta, String estadoFinal) {
        return solicitudRepository.findById(id).map(solicitud -> {
            solicitud.setRespuestaInstancia(respuesta);
            solicitud.setEstado(estadoFinal);
            solicitud.setFechaRespuesta(LocalDateTime.now());
            solicitud.setFechaActualizacion(LocalDateTime.now());
            return solicitudRepository.save(solicitud);
        }).orElse(null);
    }

    // Buscar por folio
    public Optional<Solicitud> buscarPorFolio(String folio) {
        return solicitudRepository.findByFolio(folio);
    }
}