package com.miapp.software.service;

import com.miapp.software.model.Reporte;
import com.miapp.software.repository.ReporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ReporteService {

    @Autowired
    private ReporteRepository reporteRepository;

    // RF-18, RF-19, RF-20 - Generar reporte (MO-04, C.U.5)
    public Reporte generarReporte(Reporte reporte) {
        // RNF-12: Monitoreo de tiempo de generación
        long inicio = System.currentTimeMillis();

        // Validar datos necesarios
        if (reporte.getTipoReporte() == null || reporte.getTipoReporte().isEmpty()) {
            throw new IllegalArgumentException("El tipo de reporte es obligatorio");
        }

        Reporte reporteGuardado = reporteRepository.save(reporte);

        long fin = System.currentTimeMillis();
        System.out.println("Tiempo de generación de reporte: " + (fin - inicio) + "ms");

        return reporteGuardado;
    }

    // Listar reportes generados por un usuario específico (Personal)
    public List<Reporte> listarPorUsuario(Integer idPersonal) {
        // Nota: Asegúrate que en ReporteRepository el método coincida con Personal_IdPersonal
        return reporteRepository.findByPersonal_IdPersonal(idPersonal);
    }

    // Listar por tipo de reporte (Ej: PDF, Excel, Estadístico)
    public List<Reporte> listarPorTipo(String tipoReporte) {
        return reporteRepository.findByTipoReporte(tipoReporte);
    }

    // RNF-13 - Obtener reporte para exportación
    public Optional<Reporte> obtenerPorId(Integer id) {
        return reporteRepository.findById(id);
    }

    // RNF-14 - Consultar todos los reportes (Precisión estadística)
    public List<Reporte> listarTodos() {
        return reporteRepository.findAll();
    }
}