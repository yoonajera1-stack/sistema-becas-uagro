package com.miapp.software.service;

import com.miapp.software.model.Personal;
import com.miapp.software.repository.PersonalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.List;
import java.util.Optional;

@Service
public class PersonalService {

    @Autowired
    private PersonalRepository personalRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


    // C.U.1 - Iniciar Sesión (PARA PRUEBAS - SIN BCrypt)
    public Optional<Personal> autenticar(String correo, String contraseña) {
        Optional<Personal> personal = personalRepository.findByCorreo(correo);

        if (personal.isPresent() && personal.get().getEstatus()) {
            // ✅ Validación directa (texto plano) para pruebas
            if (personal.get().getContraseña().equals(contraseña)) {
                return personal;
            }
        }
        return Optional.empty();

    }

    // MO-06 - Listar todo el personal (RF-25)
    public List<Personal> listarTodos() {
        return personalRepository.findAll();
    }

    // MO-06 - Guardar personal (RF-25)
    public Personal guardar(Personal personal) {
        // Encriptar contraseña antes de guardar si es nueva o cambió
        if (personal.getContraseña() != null && !personal.getContraseña().isEmpty()) {
            personal.setContraseña(passwordEncoder.encode(personal.getContraseña()));
        }
        return personalRepository.save(personal);
    }

    // MO-06 - Buscar por ID
    public Optional<Personal> buscarPorId(Integer id) {
        return personalRepository.findById(id);
    }

    // MO-06 - Actualizar permisos (RF-27)
    public Personal actualizarPermisos(Integer id, Personal personalActualizado) {
        return personalRepository.findById(id).map(personal -> {
            personal.setDepartamento(personalActualizado.getDepartamento());
            // ✅ CORREGIDO: getEstatus() para leer, setEstatus() para escribir
            personal.setEstatus(personalActualizado.getEstatus());
            return personalRepository.save(personal);
        }).orElse(null);
    }

    // MO-06 - Eliminar (deshabilitar) usuario
    public void deshabilitar(Integer id) {
        personalRepository.findById(id).ifPresent(personal -> {
            personal.setEstatus(false);  // ✅ setEstatus() funciona con Boolean
            personalRepository.save(personal);
        });
    }
}