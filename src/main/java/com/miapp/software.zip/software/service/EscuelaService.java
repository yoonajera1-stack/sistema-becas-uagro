package com.miapp.software.service;

import com.miapp.software.model.Escuela;
import com.miapp.software.repository.EscuelaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EscuelaService {

    @Autowired
    private EscuelaRepository escuelaRepository;

    // RF-06 - Listar escuelas activas (para formulario de estudiantes)
    public List<Escuela> listarActivas() {
        return escuelaRepository.findByEstatusTrue();
    }

    // RF-11 - Listar todas las escuelas
    public List<Escuela> listarTodas() {
        return escuelaRepository.findAll();
    }

    // RF-11 - Buscar escuela por ID
    public Optional<Escuela> buscarPorId(Integer id) {
        return escuelaRepository.findById(id);
    }

    // RF-11 - Buscar escuelas por nombre (para filtros)
    public List<Escuela> buscarPorNombre(String nombre) {
        return escuelaRepository.findByNombreContainingIgnoreCase(nombre);
    }

    // RF-11 - Buscar escuelas por tipo (Medio Superior/Superior)
    public List<Escuela> buscarPorTipo(String tipo) {
        return escuelaRepository.findByTipo(tipo);
    }

    // MO-02 - Registrar nueva escuela
    public Escuela registrar(Escuela escuela) {
        // RNF-05: Validar campos obligatorios
        if (escuela.getNombre() == null || escuela.getNombre().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la escuela es obligatorio");
        }
        if (escuela.getTipo() == null || escuela.getTipo().isEmpty()) {
            throw new IllegalArgumentException("El tipo de escuela es obligatorio");
        }
        return escuelaRepository.save(escuela);
    }

    // MO-02 - Actualizar escuela
    public Escuela actualizar(Integer id, Escuela escuelaActualizada) {
        return escuelaRepository.findById(id).map(escuela -> {
            escuela.setNombre(escuelaActualizada.getNombre());
            escuela.setTipo(escuelaActualizada.getTipo());
            escuela.setDireccion(escuelaActualizada.getDireccion());
            escuela.setTelefono(escuelaActualizada.getTelefono());
            escuela.setEmail(escuelaActualizada.getEmail());
            return escuelaRepository.save(escuela);
        }).orElse(null);
    }

    // MO-02 - Desactivar escuela
    public void desactivar(Integer id) {
        escuelaRepository.findById(id).ifPresent(escuela -> {
            escuela.setEstatus(false);
            escuelaRepository.save(escuela);
        });
    }
}