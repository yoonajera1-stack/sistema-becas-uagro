package com.miapp.software.controller;

import com.miapp.software.model.*;
import com.miapp.software.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/solicitudes")
public class SolicitudController {

    @Autowired
    private SolicitudService solicitudService;

    @Autowired
    private EstudianteService estudianteService;

    @Autowired
    private BecaService becaService;

    @Autowired
    private DocumentoService documentoService;

    @Autowired
    private RequisitoService requisitoService;

    // GET /solicitudes → Listar solicitudes (MO-03, RF-16)
    @GetMapping
    public String listarSolicitudes(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Solicitud> solicitudes = solicitudService.listarPorEstado("Pendiente");
        model.addAttribute("solicitudes", solicitudes);

        return "solicitudes/lista"; // solicitudes/lista.html
    }

    // GET /solicitudes/nueva → Mostrar formulario de nueva solicitud (RF-14, C.U.3)
    @GetMapping("/nueva")
    public String mostrarFormularioNueva(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("estudiantes", estudianteService.listarTodos());
        model.addAttribute("becas", becaService.listarActivas());
        model.addAttribute("solicitud", new Solicitud());

        return "solicitudes/formulario"; // solicitudes/formulario.html
    }

    // POST /solicitudes/guardar → Registrar nueva solicitud (RF-14, C.U.3)
    @PostMapping("/guardar")
    public String guardarSolicitud(
            @ModelAttribute Solicitud solicitud,
            @RequestParam Integer idEstudiante,
            @RequestParam Integer idBeca,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            // Obtener usuario de sesión para registrar quién creó la solicitud
            Personal personal = (Personal) session.getAttribute("usuario");

            // Asignar estudiante y beca
            Estudiante estudiante = new Estudiante();
            estudiante.setIdEstudiante(idEstudiante);
            solicitud.setEstudiante(estudiante);

            Beca beca = new Beca();
            beca.setIdBeca(idBeca);
            solicitud.setBeca(beca);

            // Asignar personal que registra
            solicitud.setPersonalRegistro(personal);

            // Registrar solicitud (genera folio automático)
            solicitudService.registrar(solicitud);

            redirectAttributes.addFlashAttribute("mensaje", "Solicitud registrada con folio generado");
            return "redirect:/solicitudes";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al registrar solicitud: " + e.getMessage());
            return "redirect:/solicitudes/nueva";
        }
    }

    // GET /solicitudes/validar/{id} → Mostrar interfaz de validación de documentos (C.U.4, RF-17)
    @GetMapping("/validar/{id}")
    public String mostrarValidacion(
            @PathVariable Integer id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Solicitud solicitud = solicitudService.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Solicitud no encontrada"));

        List<Documento> documentos = documentoService.listarPorSolicitud(id);

        model.addAttribute("solicitud", solicitud);
        model.addAttribute("documentos", documentos);

        return "solicitudes/validar"; // solicitudes/validar.html
    }

    // POST /solicitudes/validar-documento → Validar un documento individual (C.U.4, RNF-10)
    @PostMapping("/validar-documento")
    @ResponseBody
    public String validarDocumento(
            @RequestParam Integer idDocumento,
            @RequestParam boolean valido,
            @RequestParam(required = false) String observaciones) {

        try {
            documentoService.validarDocumento(idDocumento, valido, observaciones);
            return "{\"success\": true, \"message\": \"Documento validado correctamente\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"Error al validar documento\"}";
        }
    }

    // POST /solicitudes/subir-documento → Subir documento de solicitud (RF-15, RNF-09)
    @PostMapping("/subir-documento")
    public String subirDocumento(
            @RequestParam Integer idSolicitud,
            @RequestParam Integer idRequisito,
            @RequestParam("archivo") MultipartFile archivo,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            // Crear objeto documento
            Documento documento = new Documento();

            Solicitud solicitud = new Solicitud();
            solicitud.setIdSolicitud(idSolicitud);
            documento.setSolicitud(solicitud);

            Requisito requisito = new Requisito();
            requisito.setIdRequisito(idRequisito);
            documento.setRequisito(requisito);

            documento.setTipoDocumento(requisito.getNombre());

            // Subir archivo mediante el servicio
            documentoService.subirDocumento(documento, archivo);

            redirectAttributes.addFlashAttribute("mensaje", "Documento subido correctamente");

        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Error al subir documento: " + e.getMessage());
        }

        return "redirect:/solicitudes/validar/" + idSolicitud;
    }

    // POST /solicitudes/actualizar-estado/{id} → Actualizar estado de solicitud (RF-17, C.U.4)
    @PostMapping("/actualizar-estado/{id}")
    public String actualizarEstado(
            @PathVariable Integer id,
            @RequestParam String nuevoEstado,
            @RequestParam(required = false) String observaciones,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            solicitudService.actualizarEstado(id, nuevoEstado, observaciones);
            redirectAttributes.addFlashAttribute("mensaje", "Estado de solicitud actualizado correctamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar estado: " + e.getMessage());
        }

        return "redirect:/solicitudes";
    }

    // POST /solicitudes/enviar-instancia/{id} → Enviar solicitud a instancia externa (C.U.4)
    @PostMapping("/enviar-instancia/{id}")
    public String enviarAInstancia(
            @PathVariable Integer id,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            solicitudService.enviarAInstancia(id);
            redirectAttributes.addFlashAttribute("mensaje", "Solicitud enviada a instancia externa");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al enviar a instancia: " + e.getMessage());
        }

        return "redirect:/solicitudes";
    }

    // GET /solicitudes/historial → Consultar historial de solicitudes (RF-24, MO-05)
    @GetMapping("/historial")
    public String listarHistorial(
            @RequestParam(required = false) String estado,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Solicitud> solicitudes;
        if (estado != null && !estado.isEmpty()) {
            solicitudes = solicitudService.listarPorEstado(estado);
        } else {
            solicitudes = solicitudService.listarTodos();
        }

        model.addAttribute("solicitudes", solicitudes);
        model.addAttribute("estadoFiltro", estado);

        return "solicitudes/historial"; // solicitudes/historial.html
    }
}