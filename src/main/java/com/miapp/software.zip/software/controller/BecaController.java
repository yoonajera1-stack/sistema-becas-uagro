package com.miapp.software.controller;

import com.miapp.software.model.Personal;  // ✅ Import necesario
import com.miapp.software.model.Beca;
import com.miapp.software.model.Institucion;
import com.miapp.software.service.BecaService;
import com.miapp.software.service.InstitucionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;
import java.time.LocalDate;

@Controller
@RequestMapping("/becas")
public class BecaController {

    @Autowired
    private BecaService becaService;

    @Autowired
    private InstitucionService institucionService;

    // GET /becas → Listar convocatorias
    @GetMapping
    public String listarBecas(HttpSession session, Model model) {
        // ✅ Cast explícito a Personal
        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);  // ✅ Thymeleaf puede acceder a usuario.nombre
        List<Beca> becas = becaService.listarActivas();
        model.addAttribute("becas", becas);

        return "becas/lista";
    }

    // GET /becas/nueva → Mostrar formulario de nueva beca
    @GetMapping("/nueva")
    public String mostrarFormularioNueva(HttpSession session, Model model) {
        // ✅ Cast explícito a Personal
        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);  // ✅ Thymeleaf puede acceder a usuario.nombre
        model.addAttribute("instituciones", institucionService.listarActivas());
        model.addAttribute("beca", new Beca());
        model.addAttribute("modo", "crear");

        return "becas/formulario";
    }

    // POST /becas/guardar → Registrar nueva convocatoria
    @PostMapping("/guardar")
    public String guardarBeca(
            @ModelAttribute Beca beca,
            @RequestParam Integer idInstitucion,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        try {
            Institucion institucion = new Institucion();
            institucion.setIdInstitucion(idInstitucion);
            beca.setInstitucion(institucion);

            becaService.registrar(beca);

            redirectAttributes.addFlashAttribute("mensaje", "Convocatoria registrada correctamente");
            return "redirect:/becas";

        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/becas/nueva";
        }
    }

    // GET /becas/editar/{id} → Mostrar formulario de edición
    @GetMapping("/editar/{id}")
    public String mostrarEditar(
            @PathVariable Integer id,
            HttpSession session,
            Model model) {

        // ✅ Cast explícito a Personal
        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);  // ✅ Thymeleaf puede acceder a usuario.nombre

        Beca beca = becaService.obtenerPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Beca no encontrada"));

        model.addAttribute("instituciones", institucionService.listarActivas());
        model.addAttribute("beca", beca);
        model.addAttribute("modo", "editar");

        return "becas/formulario";
    }

    // POST /becas/actualizar/{id} → Actualizar convocatoria
    @PostMapping("/actualizar/{id}")
    public String actualizarBeca(
            @PathVariable Integer id,
            @ModelAttribute Beca becaActualizada,
            @RequestParam Integer idInstitucion,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        try {
            Institucion institucion = new Institucion();
            institucion.setIdInstitucion(idInstitucion);
            becaActualizada.setInstitucion(institucion);

            becaService.actualizar(id, becaActualizada);

            redirectAttributes.addFlashAttribute("mensaje", "Convocatoria actualizada correctamente");
            return "redirect:/becas";

        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/becas/editar/" + id;
        }
    }

    // GET /becas/eliminar/{id} → Eliminar/Desactivar convocatoria
    @GetMapping("/eliminar/{id}")
    public String eliminarBeca(
            @PathVariable Integer id,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        becaService.desactivar(id);

        redirectAttributes.addFlashAttribute("mensaje", "Convocatoria desactivada correctamente");
        return "redirect:/becas";
    }

    // GET /becas/historial → Listar historial de convocatorias
    @GetMapping("/historial")
    public String listarHistorial(HttpSession session, Model model) {
        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        List<Beca> todas = becaService.listarTodas();
        model.addAttribute("becas", todas);
        model.addAttribute("mostrarInactivas", true);

        return "becas/lista";
    }
}