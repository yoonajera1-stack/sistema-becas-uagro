package com.miapp.software.controller;

import com.miapp.software.model.Personal;
import com.miapp.software.model.Reporte;
import com.miapp.software.service.ReporteService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/reportes")
public class ReporteController {

    @Autowired
    private ReporteService reporteService;

    // GET /reportes → Mostrar interfaz de generación de reportes (MO-04, RF-18, RF-19, RF-20)
    @GetMapping
    public String mostrarGenerarReporte(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("reporte", new Reporte());

        // ✅ CORREGIDO: Obtener reportes recientes del usuario
        Personal usuario = (Personal) session.getAttribute("usuario");
        List<Reporte> reportesRecientes = reporteService.listarPorUsuario(usuario.getIdPersonal());
        model.addAttribute("reportesRecientes", reportesRecientes);

        return "reportes/generar"; // reportes/generar.html
    }

    // POST /reportes/generar → Generar reporte estadístico (RF-18, RNF-12, RNF-13, RNF-14)
    @PostMapping("/generar")
    public String generarReporte(
            @ModelAttribute Reporte reporte,
            @RequestParam String tipoReporte,
            @RequestParam LocalDate periodoInicio,
            @RequestParam LocalDate periodoFin,
            @RequestParam String formatoSalida,
            @RequestParam(required = false) String destinatario,
            HttpSession session,
            RedirectAttributes redirectAttributes,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            Personal usuario = (Personal) session.getAttribute("usuario");

            // Configurar reporte
            reporte.setTipoReporte(tipoReporte);
            reporte.setPeriodoInicio(periodoInicio);
            reporte.setPeriodoFin(periodoFin);
            reporte.setFormatoSalida(formatoSalida);
            reporte.setDestinatario(destinatario);
            reporte.setPersonal(usuario);

            // Generar reporte mediante el servicio
            Reporte reporteGenerado = reporteService.generarReporte(reporte);

            redirectAttributes.addFlashAttribute("mensaje", "Reporte generado exitosamente");
            redirectAttributes.addFlashAttribute("rutaReporte", reporteGenerado.getRutaArchivo());
            return "redirect:/reportes";

        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/reportes";
        }
    }

    // GET /reportes/descargar/{id} → Descargar reporte generado (RNF-13)
    @GetMapping("/descargar/{id}")
    public ResponseEntity<FileSystemResource> descargarReporte(
            @PathVariable Integer id,
            HttpSession session) {

        if (session.getAttribute("usuario") == null) {
            return null;
        }

        Reporte reporte = reporteService.obtenerPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Reporte no encontrado"));

        File archivo = new File(reporte.getRutaArchivo());
        FileSystemResource recurso = new FileSystemResource(archivo);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", archivo.getName());

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(archivo.length())
                .body(recurso);
    }

    // GET /reportes/historial → Listar historial de reportes generados
    @GetMapping("/historial")
    public String listarHistorial(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        List<Reporte> reportes = reporteService.listarPorUsuario(usuario.getIdPersonal());

        model.addAttribute("reportes", reportes);

        return "reportes/historial"; // reportes/historial.html
    }

    // GET /reportes/por-escuela → Reporte específico por escuela (RF-18)
    @GetMapping("/por-escuela")
    public String reportePorEscuela(
            @RequestParam(required = false) Integer idEscuela,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("tipoReporte", "Por Escuela");

        return "reportes/detalle"; // reportes/detalle.html
    }

    // GET /reportes/por-genero → Reporte específico por género (RF-19)
    @GetMapping("/por-genero")
    public String reportePorGenero(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("tipoReporte", "Por Género");

        return "reportes/detalle";
    }

    // GET /reportes/poblacion-vulnerable → Reporte de población vulnerable (RF-20)
    @GetMapping("/poblacion-vulnerable")
    public String reportePoblacionVulnerable(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        model.addAttribute("tipoReporte", "Población Vulnerable");

        return "reportes/detalle";
    }
}