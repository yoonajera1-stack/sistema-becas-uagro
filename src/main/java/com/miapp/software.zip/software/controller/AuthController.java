package com.miapp.software.controller;

import com.miapp.software.model.Personal;
import com.miapp.software.service.PersonalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private PersonalService personalService;

    // GET /login → Mostrar formulario de login (Interfaz 1)
    @GetMapping("/login")
    public String mostrarLogin() {
        return "login"; // Busca login.html en src/main/resources/templates/
    }

    // POST /login → Procesar autenticación (C.U.1 - RF-26, RNF-17)
    @PostMapping("/login")
    public String procesarLogin(
            @RequestParam String correo,
            @RequestParam String contraseña,
            HttpSession session,
            Model model) {

        // Intentar autenticar con el servicio
        Personal personal = personalService.autenticar(correo, contraseña)
                .orElse(null);

        if (personal != null) {
            // ✅ Credenciales correctas: crear sesión
            session.setAttribute("usuario", personal);

            // ✅ CORREGIDO: Validar que rol no sea null antes de acceder
            if (personal.getRol() != null) {
                session.setAttribute("rol", personal.getRol().getNombreRol());
            } else {
                session.setAttribute("rol", "Sin Rol");
            }

            session.setAttribute("nombre", personal.getNombre());

            // Actualizar último acceso
            personal.setUltimoAcceso(java.time.LocalDateTime.now());

            // Redirigir al Dashboard Personal (Interfaz 2)
            return "redirect:/dashboard";
        } else {
            // ❌ Credenciales incorrectas (FA_001 del C.U.1)
            model.addAttribute("error", "Correo o contraseña incorrectos");
            return "login";
        }
    }

    // GET /dashboard → Mostrar panel principal (Interfaz 2)
    @GetMapping("/dashboard")
    public String mostrarDashboard(HttpSession session, Model model) {
        // Verificar si hay sesión activa (seguridad básica)
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        model.addAttribute("usuario", usuario);

        return "dashboard"; // dashboard.html
    }

    // GET /logout → Cerrar sesión
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // Destruir sesión
        return "redirect:/login";
    }
}