package com.miapp.software.controller;

import com.miapp.software.model.Personal;
import com.miapp.software.model.Rol;
import com.miapp.software.service.PersonalService;
import com.miapp.software.service.RolService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private PersonalService personalService;

    @Autowired
    private RolService rolService;

    // GET /admin → Panel de administración (MO-06, C.U.6)
    @GetMapping
    public String mostrarPanelAdmin(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");

        // ✅ Verificar que sea administrador (RNF-04)
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard"; // Redirigir si no es admin
        }

        List<Personal> personales = personalService.listarTodos();
        model.addAttribute("personales", personales);

        return "admin/panel"; // admin/panel.html
    }

    // GET /admin/usuarios/nuevo → Mostrar formulario de nuevo usuario (RF-25)
    @GetMapping("/usuarios/nuevo")
    public String mostrarNuevoUsuario(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        model.addAttribute("roles", rolService.listarTodos());
        model.addAttribute("personal", new Personal());

        return "admin/usuario-formulario"; // admin/usuario-formulario.html
    }

    // POST /admin/usuarios/guardar → Registrar nuevo usuario (RF-25, RNF-18)
    @PostMapping("/usuarios/guardar")
    public String guardarUsuario(
            @ModelAttribute Personal personal,
            @RequestParam Integer idRol,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        try {
            // Asignar rol
            Rol rol = new Rol();
            rol.setIdRol(idRol);
            personal.setRol(rol);

            // Registrar usuario (encripta contraseña automáticamente)
            personalService.guardar(personal);

            redirectAttributes.addFlashAttribute("mensaje", "Usuario registrado correctamente");
            return "redirect:/admin";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al registrar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/nuevo";
        }
    }

    // GET /admin/usuarios/editar/{id} → Mostrar formulario de edición de usuario (RF-27)
    @GetMapping("/usuarios/editar/{id}")
    public String mostrarEditarUsuario(
            @PathVariable Integer id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        Personal personal = personalService.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        model.addAttribute("roles", rolService.listarTodos());
        model.addAttribute("personal", personal);

        return "admin/usuario-formulario";
    }

    // POST /admin/usuarios/actualizar/{id} → Actualizar permisos de usuario (RF-27)
    @PostMapping("/usuarios/actualizar/{id}")
    public String actualizarUsuario(
            @PathVariable Integer id,
            @ModelAttribute Personal personalActualizado,
            @RequestParam Integer idRol,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        try {
            Rol rol = new Rol();
            rol.setIdRol(idRol);
            personalActualizado.setRol(rol);

            personalService.actualizarPermisos(id, personalActualizado);

            redirectAttributes.addFlashAttribute("mensaje", "Usuario actualizado correctamente");
            return "redirect:/admin";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/editar/" + id;
        }
    }

    // GET /admin/usuarios/deshabilitar/{id} → Deshabilitar usuario (RF-27)
    @GetMapping("/usuarios/deshabilitar/{id}")
    public String deshabilitarUsuario(
            @PathVariable Integer id,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        try {
            personalService.deshabilitar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Usuario deshabilitado correctamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al deshabilitar usuario: " + e.getMessage());
        }

        return "redirect:/admin";
    }

    // GET /admin/bitacora → Ver bitácora de auditoría (MO-06, RNF-17)
    @GetMapping("/bitacora")
    public String mostrarBitacora(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Personal usuario = (Personal) session.getAttribute("usuario");
        if (usuario.getRol() == null || !"Administrador".equals(usuario.getRol().getNombreRol())) {
            return "redirect:/dashboard";
        }

        // Aquí iría: model.addAttribute("bitacoras", bitacoraService.listarTodos());

        return "admin/bitacora"; // admin/bitacora.html
    }
}