package com.miapp.software.controller;

import com.miapp.software.model.Estudiante;
import com.miapp.software.model.Escuela;
import com.miapp.software.service.EstudianteService;
import com.miapp.software.service.EscuelaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService;

    @Autowired
    private EscuelaService escuelaService;

    // GET /estudiantes → Listar estudiantes (MO-02, RF-11)
    @GetMapping
    public String listarEstudiantes(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        List<Estudiante> estudiantes = estudianteService.listarTodos();
        model.addAttribute("estudiantes", estudiantes);

        return "estudiantes/lista"; // estudiantes/lista.html
    }

    // GET /estudiantes/nuevo → Mostrar formulario de nuevo estudiante (RF-06)
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(HttpSession session, Model model) {
        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        // Pasar lista de escuelas para el select
        model.addAttribute("escuelas", escuelaService.listarActivas());
        model.addAttribute("estudiante", new Estudiante());
        model.addAttribute("modo", "crear");

        return "estudiantes/formulario"; // estudiantes/formulario.html
    }

    // POST /estudiantes/guardar → Registrar nuevo estudiante (RF-06, RNF-05)
    @PostMapping("/guardar")
    public String guardarEstudiante(
            @ModelAttribute Estudiante estudiante,
            @RequestParam Integer idEscuela,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            // Asignar la escuela seleccionada
            Escuela escuela = new Escuela();
            escuela.setIdEscuela(idEscuela);
            estudiante.setEscuela(escuela);

            // Establecer fecha de registro
            estudiante.setFechaRegistro(java.time.LocalDateTime.now());

            // Registrar en el servicio (valida CURP única - RF-13)
            estudianteService.registrar(estudiante);

            redirectAttributes.addFlashAttribute("mensaje", "Estudiante registrado correctamente");
            return "redirect:/estudiantes";

        } catch (IllegalArgumentException e) {
            // Manejar errores de validación (CURP duplicada, campos faltantes)
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/estudiantes/nuevo";
        }
    }

    // GET /estudiantes/editar/{id} → Mostrar formulario de edición (RF-10)
    @GetMapping("/editar/{id}")
    public String mostrarEditar(
            @PathVariable Integer id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Estudiante estudiante = estudianteService.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado"));

        model.addAttribute("escuelas", escuelaService.listarActivas());
        model.addAttribute("estudiante", estudiante);
        model.addAttribute("modo", "editar");

        return "estudiantes/formulario";
    }

    // POST /estudiantes/actualizar/{id} → Actualizar estudiante (RF-10)
    @PostMapping("/actualizar/{id}")
    public String actualizarEstudiante(
            @PathVariable Integer id,
            @ModelAttribute Estudiante estudianteActualizado,
            @RequestParam Integer idEscuela,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        try {
            Escuela escuela = new Escuela();
            escuela.setIdEscuela(idEscuela);
            estudianteActualizado.setEscuela(escuela);

            estudianteService.actualizar(id, estudianteActualizado);

            redirectAttributes.addFlashAttribute("mensaje", "Estudiante actualizado correctamente");
            return "redirect:/estudiantes";

        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/estudiantes/editar/" + id;
        }
    }

    // GET /estudiantes/buscar → Buscar estudiante por matrícula o CURP (RF-11, RNF-06)
    @GetMapping("/buscar")
    public String buscarEstudiante(
            @RequestParam(required = false) String matricula,
            @RequestParam(required = false) String curp,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Estudiante estudiante = null;

        if (matricula != null && !matricula.isEmpty()) {
            estudiante = estudianteService.buscarPorMatricula(matricula).orElse(null);
        } else if (curp != null && !curp.isEmpty()) {
            estudiante = estudianteService.buscarPorCurp(curp).orElse(null);
        }

        model.addAttribute("estudiante", estudiante);
        model.addAttribute("matricula", matricula);
        model.addAttribute("curp", curp);

        return "estudiantes/buscar"; // estudiantes/buscar.html
    }

    // GET /estudiantes/historial/{id} → Consultar historial de becas del estudiante (RF-12)
    @GetMapping("/historial/{id}")
    public String mostrarHistorial(
            @PathVariable Integer id,
            HttpSession session,
            Model model) {

        if (session.getAttribute("usuario") == null) {
            return "redirect:/login";
        }

        Estudiante estudiante = estudianteService.obtenerConHistorial(id)
                .orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado"));

        model.addAttribute("estudiante", estudiante);
        // Aquí podrías agregar: model.addAttribute("solicitudes", solicitudService.listarPorEstudiante(id));

        return "estudiantes/historial"; // estudiantes/historial.html
    }
}