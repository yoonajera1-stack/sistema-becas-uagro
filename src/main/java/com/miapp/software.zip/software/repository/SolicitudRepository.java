package com.miapp.software.repository;

import com.miapp.software.model.Solicitud;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface SolicitudRepository extends JpaRepository<Solicitud, Integer> {

    // ✅ Buscar por folio único
    Optional<Solicitud> findByFolio(String folio);

    // ✅ Buscar solicitudes de un estudiante
    List<Solicitud> findByEstudiante_IdEstudiante(Integer idEstudiante);

    // ✅ Buscar por estado (CORREGIDO: solo por 'estado', NO por 'estatus')
    List<Solicitud> findByEstado(String estado);

    // ✅ Listar todas las solicitudes
    List<Solicitud> findAll();

    }