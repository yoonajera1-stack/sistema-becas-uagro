package com.miapp.software.repository;

import com.miapp.software.model.Personal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PersonalRepository extends JpaRepository<Personal, Integer> {
    // Método personalizado para buscar por correo (para el Login - C.U.1)
    Optional<Personal> findByCorreo(String correo);

    // Método para verificar si el correo existe
    boolean existsByCorreo(String correo);
}