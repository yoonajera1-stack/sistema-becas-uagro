package com.miapp.software.repository;

import com.miapp.software.model.Reporte;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReporteRepository extends JpaRepository<Reporte, Integer> {

    // Listar reportes generados por un miembro del personal específico
    List<Reporte> findByPersonal_IdPersonal(Integer idPersonal);

    // Listar por tipo (Ej: "ESTADISTICO", "SOLICITUDES_APROBADAS", "BITACORA")
    List<Reporte> findByTipoReporte(String tipoReporte);
}
