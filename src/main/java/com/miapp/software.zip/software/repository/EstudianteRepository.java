package com.miapp.software.repository;

import com.miapp.software.model.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.List;

public interface EstudianteRepository extends JpaRepository<Estudiante, Integer> {
    // RF-13: Validar que no haya CURP duplicada
    Optional<Estudiante> findByCurp(String curp);

    // RF-11: Buscar por matrícula (único)
    Optional<Estudiante> findByMatricula(String matricula);

    // RF-11: Buscar por correo (único)
    Optional<Estudiante> findByCorreo(String correo);

    // Listar estudiantes activos
    List<Estudiante> findByEstatusTrue();

    // Buscar por escuela (para directores)
    List<Estudiante> findByEscuela_IdEscuela(Integer idEscuela);
}